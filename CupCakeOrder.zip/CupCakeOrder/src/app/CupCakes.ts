import {CupCakeTypes} from "./CupCakeTypes";

export class CupCakes {
NumberOfCupCakes :Number=0;
TypeOfCupcake:CupCakeTypes =CupCakeTypes.REDVELVET;

}
