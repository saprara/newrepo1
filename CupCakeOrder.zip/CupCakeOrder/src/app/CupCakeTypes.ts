export enum CupCakeTypes{
  VANILA="Vanila" ,
  CHOCOLATE="Chocolate",
  REDVELVET="Red Velvet",
  SALTEDCARAMEL="Salted Caramel",
  COFFEE="Coffee"

}
